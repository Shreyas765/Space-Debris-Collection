# Space Garbage Collection 

## Overview
This a GBA game where you control a spaceship that must collect space debris while avoiding dangerous asteroids. Your mission is to score at least 50 points before the time runs out. If you get hit by an asteroid however, you lose!


## Controls:
D-Pad: Move the spaceship in all four directions
START (Enter): Begin game from title screen or restart after game over
SELECT (Backspace): Return to title screen at any time (resets game state)
