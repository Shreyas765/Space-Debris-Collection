/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=16x16 spaceship images/spaceship.png 
 * Time-stamp: Thursday 04/03/2025, 18:14:57
 * 
 * Image Information
 * -----------------
 * images/spaceship.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SPACESHIP_H
#define SPACESHIP_H

extern const unsigned short spaceship[256];
#define SPACESHIP_SIZE 512
#define SPACESHIP_LENGTH 256
#define SPACESHIP_WIDTH 16
#define SPACESHIP_HEIGHT 16

#endif

