/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 titlescreen images/titlescreen_fixed.png 
 * Time-stamp: Wednesday 04/02/2025, 23:04:32
 * 
 * Image Information
 * -----------------
 * images/titlescreen_fixed.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TITLESCREEN_H
#define TITLESCREEN_H

extern const unsigned short titlescreen_fixed[38400];
#define TITLESCREEN_FIXED_SIZE 76800
#define TITLESCREEN_FIXED_LENGTH 38400
#define TITLESCREEN_FIXED_WIDTH 240
#define TITLESCREEN_FIXED_HEIGHT 160

#endif

