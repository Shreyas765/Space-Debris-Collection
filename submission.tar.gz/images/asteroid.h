/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=16x16 asteroid images/asteroid.png 
 * Time-stamp: Thursday 04/03/2025, 18:15:13
 * 
 * Image Information
 * -----------------
 * images/asteroid.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ASTEROID_H
#define ASTEROID_H

extern const unsigned short asteroid[256];
#define ASTEROID_SIZE 512
#define ASTEROID_LENGTH 256
#define ASTEROID_WIDTH 16
#define ASTEROID_HEIGHT 16

#endif

