/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=8x8 debris images/debris.png 
 * Time-stamp: Thursday 04/03/2025, 18:14:40
 * 
 * Image Information
 * -----------------
 * images/debris.png 8@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DEBRIS_H
#define DEBRIS_H

extern const unsigned short debris[64];
#define DEBRIS_SIZE 128
#define DEBRIS_LENGTH 64
#define DEBRIS_WIDTH 8
#define DEBRIS_HEIGHT 8

#endif

